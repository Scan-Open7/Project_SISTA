<?php echo form_open('daftar/save'); ?>
<form>
    <div class="form-group row">
        <h3>Pendaftaran Seminar</h3>
        <label for="nim" class="col-4 col-form-label">NIM</label>
        <div class="col-8">
            <input id="nim" name="nim" type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
        <div class="col-8">
            <input id="nama" name="nama" type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="email" class="col-4 col-form-label">Email</label>
        <div class="col-8">
            <input id="email" name="email" type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="email" class="col-4 col-form-label">Semester</label>
        <div class="col-8">
            <input id="semester" name="semester" type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="alamat" class="col-4 col-form-label">Alamat</label>
        <div class="col-8">
            <input id="alamat" name="alamat" type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-4 col-8">
            <button name="submit" type="submit" class="btn btn-primary">Daftar</button>
        </div>
    </div>
</form>
<?php echo form_close() ?>