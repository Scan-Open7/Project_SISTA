<h3>Data Daftar</h3>
<a href="<?= base_url() ?>index.php/daftar/create" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Pendaftaran Seminar</a>
<br>
<br>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>E-mail</th>
            <th>Semester</th>
            <th>Alamat</th>
            <th>View</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor = 1;
        foreach ($list_daftar->result() as $row) {
            echo '<tr><td>' . $nomor . '</td>';
            echo '<td>' . $row->nim . '</td>';
            echo '<td>' . $row->nama . '</td>';
            echo '<td>' . $row->email . '</td>';
            echo '<td>' . $row->semester . '</td>';
            echo '<td>' . $row->alamat . '</td>';
            //echo '<td>view | edit | delete</td>';
            echo '<td>

    </td>';

            echo '</tr>';
            $nomor++;
        }

        ?>
    </tbody>
</table>