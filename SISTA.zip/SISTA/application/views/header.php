<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="<?php echo base_url() ?>public/https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>public/css/styles.css" rel="stylesheet" />
    <script src="<?php echo base_url() ?>public/https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3">SISTA STT-NF</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <!-- Navbar-->
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="<?= base_url() ?>index.php/beranda">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Beranda
                        </a>
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link collapsed" href="<?= base_url() ?>index.php/dosen">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Data Dosen
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <a class="nav-link collapsed" href="<?= base_url() ?>index.php/seminar">
                            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                            Data Seminar
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                            </nav>
                        </div>
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="<?= base_url() ?>index.php/peserta">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Peserta Seminar
                        </a>
                        <a class="nav-link" href="<?= base_url() ?>index.php/nilai">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Data Nilai
                        </a>
                        <a class="nav-link" href="<?= base_url() ?>index.php/daftar">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Pendaftaran Seminar
                        </a>
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="<?= base_url() ?>index.php/berita">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Berita
                        </a>
                        <a class="nav-link" href="<?= base_url() ?>index.php/kelompok">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Kelompok
                        </a>
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="<?= base_url() ?>index.php/user/login">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Login
                        </a>
                        <?php
                        if ($this->session->has_userdata('username')) {

                        ?>
                            <li>
                                <a class="nav-link" href="<?= base_url('') ?>index.php/user/logout">Logout</a>
                            </li>
                        <?php
                        }
                        ?>

                        <li class="nav-item dropdown">
                            <?php
                            if ($this->session->has_userdata('username')) {
                                $username = $this->session->username;
                            } else {
                                $username = 'login';
                                //$link
                            }
                            ?>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small"></div>
                    SISTA STT-NF
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <ol class="breadcrumb mb-4">
                    </ol>
                    </tbody>