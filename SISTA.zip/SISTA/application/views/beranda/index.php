<style>
    .foto {
        margin-top: 100px;
        margin-bottom: 100px;
    }

    .foto h2 {
        text-align: center;
        margin-bottom: 100px;
        margin-top: -80px;
    }

    .box {
        width: 1200px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        grid-gap: 15px;
        margin: 0 auto;
    }

    .cardd {
        position: relative;
        width: 300px;
        height: 350px;
        background: #fff;
        margin: 0 auto;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, .2);
    }

    .cardd:before,
    .cardd:after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 4px;
        background: #fff;
        transition: 0.5s;
        z-index: -1;
    }

    .cardd:hover:before {
        transform: rotate(20deg);
        box-shadow: 0 2px 20px rgba(0, 0, 0, .2);
    }

    .cardd:hover:after {
        transform: rotate(10deg);
        box-shadow: 0 2px 20px rgba(0, 0, 0, .2);
    }

    .cardd .imgBx {
        position: absolute;
        top: 10px;
        left: 10px;
        bottom: 10px;
        right: 10px;
        background: #222;
        transition: 0.5s;
        z-index: 1;
    }

    .cardd:hover .imgBx {
        bottom: 100px;
    }

    .cardd .imgBx img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .cardd .details {
        position: absolute;
        left: 10px;
        right: 10px;
        bottom: 10px;
        height: 80px;
        text-align: center;
    }

    .cardd .details h2 {
        margin: 0;
        padding: 0;
        font-weight: 600;
        font-size: 20px;
        color: #777;
        text-transform: uppercase;
    }

    .cardd .details h2 span {
        font-weight: 500;
        font-size: 16px;
        color: #f38695;
        display: block;
        margin-top: 5px;
    }

    .medsos {
        list-style: none;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: -15px;
        margin-right: 40px;
    }

    .medsos li {
        margin: 0 10px;
    }

    .medsos a {
        text-decoration: none;
        color: #777;
    }

    .medsos a i {
        transition: color .4s ease;
    }

    .medsos a:hover i {
        color: #f38695;
    }
</style>
<div class="slider"></div>
<div class="bg">
    <div class="container">
        <h2 class="justify-content-center">Selamat Datang Di SISTA</h2>
        <div class="row">
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2>Pemrograman Web</h2>
                    <p>Pemrograman web dibuat dengan bahasa HTML, yaitu (Hyper text markup language). Bahasa HTML ini dikembangkan tim bernerslee pada saat mereka masih bekerja di CERN, perusahaan yang dikembangkan oleh NCSA pada tahun 1990 an.
                        HTML diresmikan pada tahun 1995, yang pada waktu itu dikembangkan oleh IETF atau Internet Engineering Task Force.
                        Kemudian menjadi Html2 yang menjadi bahasa turunan dari Html pada tahun 1993, dan Pada tahun 1995 Html dikembangkan kembali menjadi Html3, dan kemudian di kembangkan html 4 pada tahun 1997.
                    </p>
                </div>
            </div>
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2>Pengantar Teknologi</h2>
                    <p>Era pre-mekanis adalah era dimana manusia pertama kali mulai berkomunikasi dengan menggunakan bahasa sebagai alat komunikasi atau gambar di dinding goa. Selain ditemukannya sistem huruf atau alfabet dan sistem angka,
                        beberapa teknologi lain yang ditemukan pada era ini adalah kertas, pena, buku, dan kalkulator.
                        Sejarah perkembangan teknologi informasi pada era pra-mekanis berlangsung antara tahun 3000 SM hingga 1450 M. Pada tahun 3000 SM, Bangsa Sumeria di Mesopotamia telah mengembangkan tulisan pertama.
                    </p>
                </div>
            </div>
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2>Python</h2>
                    <p>Python adalah salah satu bahasa pemrograman yang dapat melakukan eksekusi sejumlah instruksi multi guna secara langsung (interpretatif) dengan metode orientasi objek. Python adalah bahasa pemrograman yang paling mudah dipahami.
                        Python dibuat oleh programmer Belanda bernama Guido Van Rossum.
                        Python sendiri menampilkan fitur-fitur menarik sehingga layak untuk Anda pelajari.
                        Python banyak diaplikasikan pada berbagai sistem operasi seperti Linux, Microsoft Windows, Mac OS, Android, Symbian OS, Amiga, Palm dan lain-lain.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2>JavaScript</h2>
                    <p>JavaScript pertama kali dikembangkan oleh Brendan Eich dari Netscape di bawah nama Mocha. JavaScript adalah bahasa pemrograman tingkat tinggi dan dinamis. JavaScript populer di internet dan dapat bekerja di sebagian besar penjelajah web populer seperti Google Chrome,
                        Internet Explorer, dan lain lain-lain. Kode JavaScript dapat disisipkan dalam
                        halaman web menggunakan tag SCRIPT. JavaScript merupakan salah satu teknologi inti World Wide Web selain HTML dan CSS. JavaScript membantu membuat halaman web interaktif dan merupakan bagian aplikasi web yang esensial.
                    </p>
                </div>
            </div>
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2 class="">Sistem Operasi</h2>
                    <p>Sistem operasi adalah perangkat lunak sistem yang bertugas untuk melakukan kontrol dan manajemen perangkat keras serta operasi-operasi dasar sistem, termasuk menjalankan perangkat lunak aplikasi seperti program-program pengolah kata dan peramban web.
                        Sedangkan software-software lainnya dijalankan setelah sistem operasi berjalan, dan sistem operasi akan melakukan layanan inti untuk software-software itu. Layanan inti tersebut seperti akses ke disk, manajemen memori, penjadwalan tugas schedule task,
                        dan antar-muka user GUI/CLI.

                    </p>
                </div>
            </div>
            <div class="col">
                <div class="card p-4 shadow-lg my-4">
                    <h2>Robotika</h2>
                    <p>Robotika adalah satu cabang teknologi yang berhubungan dengan ayen, konstruksi, operasi, disposisi struktural, pembuatan, dan aplikasi
                        dari robot. Robotika terkait dengan ilmu pengetahuan bidang elektronika dan sejenisnya. Pemikiran tentang
                        pembuatan mesin yang dapat bekerja sendiri telah ada sejak Era Klasik, tetapi riset mengenai penggunaannya
                        tidak berkembang secara berarti sampai abad ke-20. Kini, banyak robot melakukan pekerjaan yang berbahaya bagi manusia seperti menjinakkan bom, menjelajahi kapal karam, dan pertambangan.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>