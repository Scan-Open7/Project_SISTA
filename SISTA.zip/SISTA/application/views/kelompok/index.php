<style>
    .foto {
        margin-top: 100px;
        margin-bottom: 100px;
    }

    .foto h2 {
        text-align: center;
        margin-bottom: 100px;
        margin-top: -80px;
    }

    .box {
        width: 1200px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        grid-gap: 15px;
        margin: 0 auto;
    }

    .cardd {
        position: relative;
        width: 300px;
        height: 350px;
        background: #fff;
        margin: 0 auto;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, .2);
    }

    .cardd:before,
    .cardd:after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 4px;
        background: #fff;
        transition: 0.5s;
        z-index: -1;
    }

    .cardd:hover:before {
        transform: rotate(20deg);
        box-shadow: 0 2px 20px rgba(0, 0, 0, .2);
    }

    .cardd:hover:after {
        transform: rotate(10deg);
        box-shadow: 0 2px 20px rgba(0, 0, 0, .2);
    }

    .cardd .imgBx {
        position: absolute;
        top: 10px;
        left: 10px;
        bottom: 10px;
        right: 10px;
        background: #222;
        transition: 0.5s;
        z-index: 1;
    }

    .cardd:hover .imgBx {
        bottom: 100px;
    }

    .cardd .imgBx img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .cardd .details {
        position: absolute;
        left: 10px;
        right: 10px;
        bottom: 10px;
        height: 80px;
        text-align: center;
    }

    .cardd .details h2 {
        margin: 0;
        padding: 0;
        font-weight: 600;
        font-size: 20px;
        color: #777;
        text-transform: uppercase;
    }

    .cardd .details h2 span {
        font-weight: 500;
        font-size: 16px;
        color: #f38695;
        display: block;
        margin-top: 5px;
    }

    .medsos {
        list-style: none;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: -15px;
        margin-right: 40px;
    }

    .medsos li {
        margin: 0 10px;
    }

    .medsos a {
        text-decoration: none;
        color: #777;
    }

    .medsos a i {
        transition: color .4s ease;
    }

    .medsos a:hover i {
        color: #f38695;
    }
</style>
<div class="foto">
    <h2>Anggota Kelompok</h2>
    <div class="row">
        <div class="cardd">
            <div class="imgBx">
                <img src="index.php/img/fatchan.jpeg" alt="images">
            </div>
            <div class="details">
                <h2>Fatchan Muhammad H<br><span>Ketua</span></h2><br>
                <ul class="medsos">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>

        <div class="cardd">
            <div class="imgBx">
                <img src="/img/" alt="images">
            </div>
            <div class="details">
                <h2>Mariam<br><span>Support</span></h2><br>
                <ul class="medsos">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>

        <div class="cardd">
            <div class="imgBx">
                <img src="https://scontent.fcgk18-1.fna.fbcdn.net/v/t1.0-9/48422783_307107446579226_7616163264300318720_o.jpg?_nc_cat=105&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeHLRL4vhkrYmJrBORFa3dfJeI36oUzH5Q14jfqhTMflDUtlPkOGZUnvmXeDdAQ4TyBHwyvnQUxDlmdC8GqKU8UD&_nc_ohc=udZXa9ieNdkAX8hHMPl&_nc_ht=scontent.fcgk18-1.fna&oh=d328a9dd7333e6dec8cda97f5498ef7c&oe=60377E1D" alt="images">
            </div>
            <div class="details">
                <h2>Maulana Hisyam<br><span>-</span></h2><br>
                <ul class="medsos">
                    <li><a href="https://www.facebook.com/maulana.hisyam.142/"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/maulana_7_hisyam/"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<br>
<br>