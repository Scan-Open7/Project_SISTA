<table class="table">
    <h3>Data Seminar</h3>
    <thead>
        <tr>
            <th>#</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Semester</th>
            <th>Kategori</th>
            <th>Pembimbing</th>
            <th>Penguji_1</th>
            <th>Punguji_2</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Materi</th>
            <th>Lokasi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor = 1;
        foreach ($list_seminar as $seminar_ta) {
        ?>
            <tr>
                <td><?= $nomor ?></td>
                <td><?= $seminar_ta->nim ?></td>
                <td><?= $seminar_ta->nama_mahasiswa ?></td>
                <td><?= $seminar_ta->semester ?></td>
                <td><?= $seminar_ta->kategori_seminar_id ?></td>
                <td><?= $seminar_ta->pembimbing_id ?></td>
                <td><?= $seminar_ta->penguji1_id ?></td>
                <td><?= $seminar_ta->penguji2_id ?></td>
                <td><?= $seminar_ta->tanggal ?></td>
                <td><?= $seminar_ta->jam ?></td>
                <td><?= $seminar_ta->judul ?></td>
                <td><?= $seminar_ta->lokasi ?></td>
            </tr>
        <?php
            $nomor++;
        }
        ?>
    </tbody>
</table>