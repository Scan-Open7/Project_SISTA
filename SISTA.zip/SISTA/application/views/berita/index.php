    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }


        @import url('https://fonts.googleapis.com/css?family=Arapey');

        body {
            margin: 0;
            font-family: 'Arapey';
        }

        nav .navbar {
            background-color: black;
            padding: 0;
        }

        .navbar-brand {
            margin-left: 20px;
            width: 100px;
        }

        .nav-link {
            margin: 0 10px 0 0;
        }

        .navbar-nav button a,
        .navbar-nav button,
        .navbar-nav h3 {
            color: white;
        }

        .bg {
            background: url("https://wallpaper.dog/large/10893206.jpg") repeat fixed 100%;
            padding-top: 30px;
            padding-bottom: 20px;
            text-align: center;
        }

        .bg h1 {
            position: relative;
            font-family: Georgia, 'Times New Roman', Times, serif;
            top: -200px;
            font-size: 70px;
            color: white;
        }

        .bg p {
            position: relative;
            font-family: 'stencil';
        }

        h2 {
            text-align: center;
            margin-top: 40px;
        }


        h1 {
            font-size: 2em;
            text-align: center;
            margin-top: 30%;
        }

        section {
            padding: 3em;
            height: 100vh;
            position: relative;
            box-sizing: border-box;
        }

        blockquote {
            font-size: 2em;
            width: 30%;
            margin-top: 17%;
            position: absolute;
        }

        span {
            width: 100%;
            background: red;
            display: block;
            height: 5px;
            margin-top: 20px;
        }

        .sticky img {
            position: absolute;
        }

        img:nth-of-type(1) {
            width: 50%;
            right: -5%;
            top: 3%;
        }

        img:nth-of-type(2) {
            width: 25%;
            right: 40%;
            top: 29%;
            margin-top: 15%;
        }

        .sticky {
            background: white !important;
        }

        section:nth-of-type(odd) {
            background: #f1f1f1;
        }

        #box {
            width: 100px;
            height: 100px;
            position: absolute;
            border: 5px solid lightgray;
            margin: auto;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
        }



        .card1 {
            position: relative;
            margin: 30px 30px;
            height: 440px;
            width: 310px;
            display: flex;
            background: white;
            box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.15);
            transition: 0.4s linear;
        }

        .card1:hover {
            box-shadow: 0px 1px 35px 0px rgba(0, 0, 0, 0.3);
        }

        .card1 .image {
            background: black;
            height: 400px;
            overflow: hidden;
        }

        .card1 .image img {
            height: 100%;
            width: 100%;
            transition: 00.3s;
        }

        .card1.active .image img {
            opacity: 0.6;
            transform: scale(1.1);
        }

        .card1 .content {
            position: absolute;
            bottom: 0px;
            background: white;
            width: 100%;
            text-align: center;
            padding: 20px 30px;
        }


        .card2 {
            position: relative;
            margin: 30px 30px;
            height: 440px;
            width: 310px;
            display: flex;
            background: white;
            box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.15);
            transition: 0.4s linear;
        }

        .card2:hover {
            box-shadow: 0px 1px 35px 0px rgba(0, 0, 0, 0.3);
        }

        .card2 .image {
            background: black;
            height: 400px;
            overflow: hidden;
        }

        .card2 .image img {
            height: 100%;
            width: 100%;
            transition: 00.3s;
        }

        .card2.active .image img {
            opacity: 0.6;
            transform: scale(1.1);
        }

        .card2 .content {
            position: absolute;
            bottom: 0px;
            background: white;
            width: 100%;
            text-align: center;
            padding: 20px 30px;
        }


        .card3 {
            position: relative;
            margin: 30px 30px;
            height: 440px;
            width: 310px;
            display: flex;
            background: white;
            box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.15);
            transition: 0.4s linear;
        }

        .card3:hover {
            box-shadow: 0px 1px 35px 0px rgba(0, 0, 0, 0.3);
        }

        .card3 .image {
            background: black;
            height: 400px;
            overflow: hidden;
        }

        .card3 .image img {
            height: 100%;
            width: 100%;
            transition: 00.3s;
        }

        .card3.active .image img {
            opacity: 0.6;
            transform: scale(1.1);
        }

        .card3 .content {
            position: absolute;
            bottom: 0px;
            background: white;
            width: 100%;
            text-align: center;
            padding: 20px 30px;
        }


        .content .title {
            font-size: 24px;
            font-weight: 600;
            color: #333333;
        }

        .content .sub-title {
            font-size: 18px;
            font-weight: 500;
            color: #e74c3c;
        }

        .bottom p {
            color: #666666;
            font-size: 16px;
            text-align: justify;
            line-height: 1.8rem;
        }

        .bottom button {
            float: left;
            padding: 7px 15px;
            font-size: 17px;
            background: #e74c3c;
            color: white;
            font-weight: 500;
            border: none;
            margin: 10px 0;
            cursor: pointer;
            transition: 00.3s ease;
        }

        .bottom button:hover {
            transform: scale(0.9);
            background: #e64533;
        }

        .bottom {
            display: none;
        }

        .socials {
            list-style: none;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 1rem 0 3rem 0;
        }

        .socials li {
            margin: 0 10px;
        }

        .socials a {
            text-decoration: none;
            color: white;
        }

        .socials a i {
            font-size: 1.1rem;
            transition: color .4s ease;
        }

        .socials a:hover i {
            color: aqua;
        }
    </style>
    <div class="bg">
        <h1>Berita Seputar <p>Universitas</p>
        </h1>
    </div>

    <h2>Berita Terhangat!!!</h2>


    <section class="sticky">
        <blockquote>"Rektor Universitas Lampung Serah Terima Jabatan Kepala Sekolah YP Unila"<span></span></blockquote>
        <img id="office" src="https://cdn-2.tstatic.net/lampung/foto/bank/images/rekror-unila.jpg">
        <img id="building" src="https://th.bing.com/th/id/OIP.RZ50KHqsNEaK6l3vslc62wHaFj?pid=Api&rs=1">
        <div id="box"></div>
    </section>


    </header>


    <div class="row">
        <div class="col">
            <div class="card1">
                <div class="image">
                    <img src="https://akcdn.detik.net.id/community/media/visual/2020/10/21/wisuda-virtual-pertama-universitas-gajah-mada-5_169.jpeg?w=700&q=90" alt="">
                </div>
                <div class="content">
                    <div class="title">Jenis Perguruan Tinggi</div>
                    <div class="sub-title">Mengenal Bentuk Perguruan Tinggi: Universitas, Institut, dan Sekolah Tinggi</div>
                    <div class="bottom">
                        <p>detikers yang saat ini hendak melanjutkan pendidikan ke perguruan tinggi, sudah tahukan perbedaan Universitas, Institut, dan Sekolah Tinggi? Apa saja perbedaan ketiganya?</p>
                        <button><a href="https://news.detik.com/berita/d-5350570/mengenal-bentuk-perguruan-tinggi-universitas-institut-dan-sekolah-tinggi?_ga=2.88940827.1008270907.1611842978-1529897818.1609120776">Read More</a></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card2">
                <div class="image">
                    <img src="https://akcdn.detik.net.id/community/media/visual/2021/01/08/keren-kampus-di-lampung-gunakan-plts-terbesar-1_169.jpeg?w=700&q=90" alt="">
                </div>
                <div class="content">
                    <div class="title">Universitas di Lampung</div>
                    <div class="sub-title">Keren! Kampus di Lampung Gunakan PLTS Terbesar</div>
                    <div class="bottom">
                        <p>Kampus di Lampung ini menggunakan PLTS (Pembangkit Listrik Tenaga Surya) terbesar dan bisa menghasilkan energi sebesar 1 Megawatt-peak (MWp) untuk kebutuhannya.</p>
                        <button><a href="https://finance.detik.com/foto-bisnis/d-5326016/keren-kampus-di-lampung-gunakan-plts-terbesar?_ga=2.258819466.1008270907.1611842978-1529897818.1609120776">Read More</a></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card3">
                <div class="image">
                    <img src="https://akcdn.detik.net.id/community/media/visual/2020/07/05/suasana-utbk-hari-pertama-di-ugm-1_169.jpeg?w=700&q=90" alt="">
                </div>
                <div class="content">
                    <div class="title">Pendaftaran SNMPTN 2021</div>
                    <div class="sub-title">Cara Daftar, Jadwal dan Syarat, Cek di https://ltmpt.ac.id/</div>
                    <div class="bottom">
                        <p>SNMPTN 2021 informasinya sudah bisa dilihat melalui laman resmi Lembaga Tes Masuk Perguruan Tinggi atau LTMPT di https://ltmpt.ac.id/. Informasi yang tersedia antara lain: jadwal SNMPTN 2021 dan UTBK-SBMPTN 2021.</p>
                        <button><a href="https://news.detik.com/berita/d-5294285/snmptn-2021-cara-daftar-jadwal-dan-syarat-cek-di--httpsltmptacid?_ga=2.20791608.1008270907.1611842978-1529897818.1609120776">Read More</a></button>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <script>
        $('.card1').hover(function() {
            if ($(this).hasClass("active")) {
                $('.card1 .bottom').slideUp(function() {
                    $('.card1').removeClass("active");
                });
            } else {
                $('.card1').addClass("active");
                $('.card1 .bottom').stop().slideDown();
            }
        });

        $('.card2').hover(function() {
            if ($(this).hasClass("active")) {
                $('.card2 .bottom').slideUp(function() {
                    $('.card2').removeClass("active");
                });
            } else {
                $('.card2').addClass("active");
                $('.card2 .bottom').stop().slideDown();
            }
        });

        $('.card3').hover(function() {
            if ($(this).hasClass("active")) {
                $('.card3 .bottom').slideUp(function() {
                    $('.card3').removeClass("active");
                });
            } else {
                $('.card3').addClass("active");
                $('.card3 .bottom').stop().slideDown();
            }
        });
    </script>
    <br>
    <br>