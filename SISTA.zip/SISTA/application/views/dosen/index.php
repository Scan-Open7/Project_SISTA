<script>
    function hapusDosen(Pesan) {
        if (confirm(pesan)) {
            return true;
        } else {
            return false;
        }
    }
</script>

<h3>Data Dosen</h3>
<a href="<?= base_url() ?>index.php/dosen/create" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Create Dosen</a>
<br>
<br>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>NIDN</th>
            <th>Nama Dosen</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor = 1;
        foreach ($list_dosen->result() as $row) {
            echo '<tr><td>' . $nomor . '</td>';
            echo '<td>' . $row->nidn . '</td>';
            echo '<td>' . $row->nama . '</td>';
            //echo '<td>view | edit | delete</td>';
            echo '<td>
    <a href="' . base_url() . 'index.php/dosen/view/' . $row->id . '" class="btn btn-success btn-lg active" role="button" aria-pressed="true">View</a>
    <a href="' . base_url() . 'index.php/dosen/edit/' . $row->id . '" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Edit</a>
    <a href="' . base_url() . 'index.php/dosen/delete/' . $row->id . '" class="btn btn-danger btn-lg active" role="button" aria-pressed="true"
    onclick="return hapusDosen(\'Data Dosen ' . $row->nama . ' Yakin mau dihapus ?? \')">Delete</a>
    </td>';

            echo '</tr>';
            $nomor++;
        }

        ?>
    </tbody>
</table>