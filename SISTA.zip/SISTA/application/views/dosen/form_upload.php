<h3>Upload Foto Dosen</h3>

NIDN : <?= $objdosen->nidn ?>
<br />
Nama : <?= $objdosen->nama ?>
<br />
<img src="<?= base_url() ?>/index.php/photos/photos/<?= $objdosen->nidn ?>.jpg" width="20%" alt="">
<br />
<?php echo $error; ?>
<?php echo form_open_multipart('foto'); ?>

<!--Isi Form-->

</form>
<input type="file" name="fotodosen" size="20">
<input type="hidden" name="iddosen" value="<?= $objdosen->id ?>" />
<br /><br />
<input type="submit" value="upload" />

</form>