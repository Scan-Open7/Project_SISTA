<?php
//Tangkap Request Form Upload
$namafile = $_FILES['photos']['name'];
$tmpfile  = $_FILES['uploads']['tmp_name'];

// Tentukan Lokasi Upload File
$direktori_upload = "foto";
// Pindahkan File Upload
$terupload = move_uploaded_file($tmpfile, $direktori_upload . $namafile);

if ($terupload) {
    echo '<pre>';
    print_r($_FILES);
    echo '</pre>';
    echo '<h3?>Upload Sukses!!</h3>';
    echo '<img src="/photos/photos/"' . $direktori_upload . $namafile . '" alt="" width="40%"/>';
    echo '<br/>File : ' . $direktori_upload . $namafile;
} else {
    echo '<h3>Upload Gagal!!</h3>';
}
