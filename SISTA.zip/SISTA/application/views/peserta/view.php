<h3>DataPasien#ID:<?= $peserta_seminar->id ?></h3>
<div>
    <tableclass="tabletable-striped">
        <tr>
            <td>NIM</td>
            <td>:</td>
            <td><?= $peserta_seminar->kode ?></td>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><?= $peserta_seminar->nama ?></td>
        </tr>
        <tr>
            <td>Seminar</td>
            <td>:</td>
            <td><?= $peserta_seminar->seminar_id ?></td>
        </tr>
        <tr>
            <td>Kehadiran</td>
            <td>:</td>
            <td><?= $peserta_seminar->kehadiran ?></td>
        </tr>
        </tr>
        </table>
</div>