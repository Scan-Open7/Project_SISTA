<table class="table">
    <h3>Data Peserta</h3>
    <thead>
        <tr>
            <th>#</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Seminar</th>
            <th>Kehadiran</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor = 1;
        foreach ($list_peserta as $peserta_seminar) {
        ?>
            <tr>
                <td><?= $nomor ?></td>
                <td><?= $peserta_seminar->nim ?></td>
                <td><?= $peserta_seminar->nama ?></td>
                <td><?= $peserta_seminar->seminar_id ?></td>
                <td><?= $peserta_seminar->kehadiran ?></td>
            </tr>
        <?php
            $nomor++;
        }
        ?>
    </tbody>
</table>