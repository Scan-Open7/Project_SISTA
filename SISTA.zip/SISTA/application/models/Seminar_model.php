<?php
class Seminar_model extends CI_Model
{
    public  $id;
    public  $nim;
    public  $nama;
    public  $semester;
    public  $kategori_seminar_id;
    public  $pembimbing_id;
    public  $penguji1_id;
    public  $penguji2_id;
    public  $tanggal;
    public  $jam;
    public  $judul;
    public  $lokasi;

    public function getAll()
    {
        // Select * From Seminar
        $query = $this->db->get('seminar_ta');
        return $query;
    }
    public function findById($id)
    {
        // Select * From Seminar Where id=$id
        $query = $this->db->get_where('seminar_ta', ['id' => $id]);
        return $query->row();
    }
}
