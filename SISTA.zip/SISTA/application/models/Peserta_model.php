<?php
class Peserta_model extends CI_Model
{
    public  $id;
    public  $nim;
    public  $nama;
    public  $seminar_id;
    public  $kehadiran;
    public  $view;

    public function getAll()
    {
        // Select * From Peserta
        $query = $this->db->get('peserta_seminar');
        return $query;
    }
    public function findById($id)
    {
        // Select * From Peserta Where id=$id
        $query = $this->db->get_where('peserta_seminar', ['id' => $id]);
        return $query->row();
    }
}
