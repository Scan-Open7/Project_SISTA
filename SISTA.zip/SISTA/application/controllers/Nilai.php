<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Nilai extends CI_Controller
{
    public function index()
    {
        $this->load->model('detail_model', 'detail1');
        $this->detail1->id = '1';
        $this->detail1->penilaian_id = '2';
        $this->detail1->dosen_id = 'Budi Hakim';
        $this->detail1->seminar_id = '1';
        $this->detail1->nilai = '2';

        $list_detail = [$this->detail1];
        $data['list_detail'] = $list_detail;

        $this->load->view('header');
        $this->load->view('nilai/index', $data);
        $this->load->view('footer');
    }
    public function list()
    {
        $this->load->model('detail_model');
        $data['detail'] = $this->detail_model->getAll();

        $this->load->view('header');
        $this->load->view('nilai/list', $data);
        $this->load->view('footer');
    }
    public function view($id)
    {
        $this->load->model('detail_model');
        $data['detail'] = $this->detail_model->findById($id);

        $this->load->view('header');
        $this->load->view('nilai/view', $data);
        $this->load->view('footer');
    }
}
