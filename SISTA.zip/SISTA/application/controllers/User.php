<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function login()
    {
        $_username = $this->input->post('username');
        $_pass = $this->input->post('pass');
        if (!empty($_username)) {
            if ($_username == 'admin' && $_pass == 'adminis') {
                $this->session->set_userdata('username', $_username);
                $this->session->set_userdata('role', 'Administror');
                redirect(base_url(), 'refresh');
            } else {
                $data['info'] = 'Username atau Password Anda Salah';
            }
        }

        $data[] = '';
        $this->load->view('header');
        $this->load->view('user/login', $data);
        $this->load->view('footer');
    }
    public function logout()
    {
        session_destroy();
        redirect('user/login', 'refresh');
    }
}
